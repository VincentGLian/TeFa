import bag from "../assets/images/bag.png";
import back from "../assets/images/Back.png";
import rect from "../assets/images/rect.png";
import vector from "../assets/images/Vector.png";
import sofa from "../assets/images/sofa.png";
import star from "../assets/images/star.png";
import cacha from "../assets/images/cacha.png";
import loc from "../assets/images/loc.png";
import chat from "../assets/images/chat.png";
import cart from "../assets/images/cart.png";

export default {
    bag,
    back,
    rect,
    vector,
    sofa,
    star,
    cacha,
    loc,
    chat,
    cart,
};