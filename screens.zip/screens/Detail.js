import { View, Text, SafeAreaView, Image, ScrollView, TouchableOpacity } from 'react-native'
import React from 'react'
import { CircleButton } from '../components/Button'
import { assets } from '../constants'

const Detail = () => {
  return (
    <SafeAreaView style={{ flex:1, backgroundColor:"#FAFAFA" }}>
        <ScrollView showsVerticalScrollIndicator={false}>

        <View style={{ flex:1 }}>
            <CircleButton imgUrl={assets.back} left={20} top={30}/>
            <Text style={{ 
                textAlign:'center',
                fontSize:20,
                fontWeight:'900',
                marginTop:30,
                color:'black'
             }}>Detail Produk</Text>
            <CircleButton imgUrl={assets.vector} right={20} top={30}/>
        </View>

        <View>
            <Image source={assets.sofa} style={{ alignSelf:'center', marginTop:40, width:400 }}/>
        </View>

        <View style={{ backgroundColor:'white', marginTop:30 }}>
            <View style={{ flexDirection:'row', justifyContent:'space-between', margin:20 }}>
                <Text style={{ 
                    fontSize:20,
                    fontWeight:'900',
                    color:'black'
                }}>Sofa Ternyaman</Text>
                <Text>Rp. 3.000.000</Text>
            </View>
            <View style={{ flexDirection:'row', margin:20, marginTop:0 }}>
                <View style={{ flexDirection:'row', borderWidth:1, width:80, borderRadius:5, justifyContent:'center' }}>
                    <Image source={assets.star} style={{ marginRight:10, marginTop:3 }}/>
                    <Text style={{ fontWeight:'bold' }}>4.4/5</Text>
                </View>
                <Text style={{ marginLeft:20, fontWeight:'900' }}>150+ Review</Text>
            </View>
        </View>

        <View style={{ backgroundColor:'white', marginTop:10 }}>
            <View style={{ flexDirection:'row', margin:20 }}>
                <Image source={assets.cacha} style={{ borderRadius:100 }} />
                <View style={{ marginLeft:10 }}>
                    <Text style={{ fontWeight:'700', fontSize:17 }}>Cashaofficial</Text>
                    <View style={{ flexDirection:'row' }}>
                        <Image source={assets.loc} style={{ marginTop:10 }}/>
                        <Text style={{ marginTop:5, marginLeft:10 }}>Air Mati</Text>
                        <TouchableOpacity style={{ borderWidth:1, marginLeft: 150, padding:5, textAlign:'center' }}>
                            <Text>Kunjungi Toko</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </View>

        <View style={{ backgroundColor:'white', marginTop:10 }}>
            <Text style={{ margin:20, marginTop:10, marginBottom:5, fontWeight:'900', fontSize:14 }}>Rincian Produk</Text>
            <View style={{ margin:20, marginTop:10, marginBottom:5, flexDirection:'row' }}>
                <Text>stok</Text>
                <Text style={{ marginLeft: 150 }}>30</Text>
            </View>
            <View style={{ margin:20, marginTop:10, marginBottom:5, flexDirection:'row' }}>
                <Text>Merek</Text>
                <Text style={{ marginLeft: 137 }}>Yukata</Text>
            </View>
            <View style={{ margin:20, marginTop:10, marginBottom:5, flexDirection:'row' }}>
                <Text>Kain Pelapis</Text>
                <Text style={{ marginLeft: 100 }}>Katun</Text>
            </View>
            <View style={{ margin:20, marginTop:10, marginBottom:5, flexDirection:'row' }}>
                <Text>Negara Asal</Text>
                <Text style={{ marginLeft: 100 }}>Indonesia</Text>
            </View>
            <View style={{ margin:20, marginTop:10, flexDirection:'row' }}>
                <Text>Jumlah Tempat Duduk</Text>
                <Text style={{ marginLeft: 35 }}>3</Text>
            </View>
        </View>

        <View style={{ backgroundColor:'white', marginTop:10 }}>
            <Text style={{ margin:20 }}>Deskripsi produk</Text>
            <Text style={{ margin:20, marginTop:0 }}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </Text>
        </View>

        <View style={{ flexDirection:'row', justifyContent:'space-between' }}>
            <TouchableOpacity style={{
                backgroundColor: "#206454",
                borderRadius:10,
                width:70,
                marginTop:0,
                marginLeft:20,
                marginBottom:20,
                padding: 15,
            }}>
                <Image source={assets.chat} style={{ alignSelf:'center' }} />
            </TouchableOpacity>
            <TouchableOpacity style={{
                backgroundColor: "#206454",
                borderRadius:10,
                width:70,
                marginBottom:20,
                marginTop:0,
                padding: 15,
            }}>
                <Image source={assets.cart} style={{ alignSelf:'center' }} />
            </TouchableOpacity>
            <TouchableOpacity style={{
                backgroundColor: "#206454",
                borderRadius:10,
                width:200,
                marginRight:20,
                marginBottom:20,
                marginTop:0,
                padding: 15,
            }}>
                <Text style={{ 
                    fontSize: 15,
                    fontWeight:'900',
                    color: 'white',
                    textAlign: 'center'
                }}>
                    Beli Sekarang
                </Text>
            </TouchableOpacity>
        </View>
        
        </ScrollView>
    </SafeAreaView>
  )
}

export default Detail