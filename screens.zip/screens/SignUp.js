import { View, Text, SafeAreaView, TextInput, TouchableOpacity } from 'react-native'
import React from 'react'
import { CircleButton } from '../components/Button'
import { assets,COLORS } from '../constants'

const SignUp = () => {
  const [text, onChangeText] = React.useState("");
  const [number, onChangeNumber] = React.useState(null);
  return (
    <SafeAreaView style={{ flex:1, backgroundColor:'#206454' }}>
      <View style={{ flex:1 }}>

        <View>
            <CircleButton imgUrl={assets.back} left={20} top={30}/>
            <Text style={{ 
                fontSize:40,
                fontWeight:'bold',
                textAlign:'center',
                marginTop:80,
                color:'white',
            }}>Register</Text>
            <Text style={{ 
                fontSize:12,
                textAlign:'center',
                color:'white'
            }}>buat akun baru anda</Text>
        </View>

        <View style={{ backgroundColor:'white', height:'100%', borderTopLeftRadius:25, borderTopRightRadius:25, marginTop:50 }}>
            <TextInput onChangeText={onChangeText} value={text} 
            style={{ borderRadius:10, borderWidth:1, marginLeft:20, marginRight:20, marginTop:40, padding:15 }}
            placeholder="masukkan nama anda"/>
            <TextInput onChangeText={onChangeText} value={text} 
            style={{ borderRadius:10, borderWidth:1, marginLeft:20, marginRight:20, marginTop:40, padding:15 }}
            placeholder="Email"/>
            <TextInput onChangeText={onChangeText} value={text} 
            style={{ borderRadius:10, borderWidth:1, marginLeft:20, marginRight:20, marginTop:40, padding:15 }}
            placeholder="password"/>
            <TextInput onChangeText={onChangeText} value={text} 
            style={{ borderRadius:10, borderWidth:1, marginLeft:20, marginRight:20, marginTop:40, padding:15 }}
            placeholder="konfirmasi password"/>
            
            <Text style={{ 
                textAlign:'center',
                marginLeft:50,
                marginRight:50,
                marginTop:20,
                marginBottom:25
             }}>Dengan mendaftar kamu menyutujui kebijakan privasi dan syarat & ketentuan kami</Text>
            <TouchableOpacity style={{ 
                width:370,
                height:50,
                alignSelf: 'center',
                backgroundColor:'#206454',
                borderRadius:20,
                justifyContent:'center'
             }}>
                <Text style={{ 
                    textAlign:'center',
                    fontWeight:'700',
                    fontSize:20,
                    color:'white'
                 }}>Daftar Sekarang</Text>
            </TouchableOpacity>
            <Text style={{ 
                textAlign:'center',
                margin:10
             }}>Sudah memiliki akun? Masuk</Text>
        </View>
        
      </View>
    </SafeAreaView>
  )
}

export default SignUp