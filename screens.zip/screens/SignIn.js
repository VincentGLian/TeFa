import { View, Text, SafeAreaView, TextInput, TouchableOpacity, Image } from 'react-native'
import React from 'react'
import { CircleButton } from '../components/Button'
import { assets } from '../constants'

const SignIn = () => {
  const [text, onChangeText] = React.useState("");
  const [number, onChangeNumber] = React.useState(null);
  return (
    <SafeAreaView style={{ flex:1, backgroundColor:'#206454' }}>
      <View style={{ flex:1 }}>

        <View>
            <CircleButton imgUrl={assets.back} left={20} top={30}/>
            <Image source={assets.bag} style={{ 
                alignSelf:'center',
                marginTop: 20,
                color:'white',
            }}/>
            <Text style={{ 
                fontSize:15,
                textAlign:'center',
                color:'white',
                marginTop: 10
            }}>One Solok</Text>
        </View>

        <View style={{ backgroundColor:'white', height:'100%', borderTopLeftRadius:25, borderTopRightRadius:25, marginTop:20 }}>
            <Text style={{ 
                fontSize: 32,
                fontWeight:'700',
                marginTop:20,
                textAlign:'center',
                color:'#206454'
             }}>Selamat Datang</Text>

            <TextInput onChangeText={onChangeText} value={text} 
            style={{ borderRadius:10, borderWidth:1, marginLeft:20, marginRight:20, marginTop:40, padding:15 }}
            placeholder="Username"/>
            <TextInput onChangeText={onChangeText} value={text} 
            style={{ borderRadius:10, borderWidth:1, marginLeft:20, marginRight:20, marginTop:40, padding:15 }}
            placeholder="Password"/>

            <View style={{ flexDirection:'row' }}>
                <TouchableOpacity style={{ 
                    width:15,
                    height:15,
                    marginLeft:50,
                    marginTop:20,
                    borderWidth:1
                 }} />
                <Text style={{ marginLeft:5, marginTop:18 }}>Ingat Password</Text>
                <Text style={{ marginLeft:80, marginTop:18, fontWeight:'bold' }}>Lupa Password?</Text>
            </View>

            <TouchableOpacity style={{ 
                width:370,
                height:50,
                alignSelf: 'center',
                backgroundColor:'#206454',
                borderRadius:20,
                marginTop:50,
                justifyContent:'center'
             }}>
                <Text style={{ 
                    textAlign:'center',
                    fontWeight:'700',
                    fontSize:20,
                    color:'white'
                 }}>Masuk</Text>
            </TouchableOpacity>
              <Text style={{ 
                textAlign:'center',
                margin:10
             }}>Belum memiliki akun? Daftar disini</Text>
        </View>

      </View>
    </SafeAreaView>
  )
}

export default SignIn